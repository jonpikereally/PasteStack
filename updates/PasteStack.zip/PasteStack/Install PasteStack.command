#!/bin/bash
# PasteStack installer — copies the app to ~/Applications and launches it.
cd "$(dirname "$0")"
fail() {
  echo
  echo "Error $1: $2"
  echo "Look up this code on the PasteStack error list:"
  echo "  https://github.com/jonpikereally/PasteStack/blob/main/ERRORS.md"
  echo "(You can also give that page to an AI assistant for help.)"
  exit 1
}
echo "Installing PasteStack…"
mkdir -p ~/Applications || fail PS-601 "Couldn't create ~/Applications."
rm -rf ~/Applications/PasteStack.app
ditto --norsrc PasteStack.app ~/Applications/PasteStack.app \
  || fail PS-601 "Couldn't copy PasteStack into ~/Applications."
# Clear the download quarantine and re-sign locally so macOS trusts it on this Mac.
xattr -dr com.apple.quarantine ~/Applications/PasteStack.app 2>/dev/null
codesign --force --sign - ~/Applications/PasteStack.app 2>/dev/null \
  || fail PS-602 "Couldn't sign PasteStack for this Mac."
open ~/Applications/PasteStack.app \
  || fail PS-603 "PasteStack was installed but couldn't be opened. Open it from ~/Applications yourself."
echo
echo "Done! Look for the clipboard icon in your menu bar."
echo "Grant the Accessibility permission when asked — that lets PasteStack"
echo "paste for you automatically. Then press Shift+Cmd+V anywhere."
