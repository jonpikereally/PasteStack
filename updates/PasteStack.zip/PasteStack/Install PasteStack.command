#!/bin/bash
# PasteStack installer — copies the app to ~/Applications and launches it.
cd "$(dirname "$0")"
echo "Installing PasteStack…"
mkdir -p ~/Applications
rm -rf ~/Applications/PasteStack.app
ditto --norsrc PasteStack.app ~/Applications/PasteStack.app
# Clear the download quarantine and re-sign locally so macOS trusts it on this Mac.
xattr -dr com.apple.quarantine ~/Applications/PasteStack.app 2>/dev/null
codesign --force --sign - ~/Applications/PasteStack.app
open ~/Applications/PasteStack.app
echo
echo "Done! Look for the clipboard icon in your menu bar."
echo "Grant the Accessibility permission when asked — that lets PasteStack"
echo "paste for you automatically. Then press Shift+Cmd+V anywhere."
