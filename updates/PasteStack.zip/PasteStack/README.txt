PasteStack v1.16 — a free, local clipboard manager for macOS (13+)
https://github.com/jonpikereally/PasteStack

INSTALL
1. Double-click "Install PasteStack.command".
   If macOS blocks it: right-click it, choose Open, then Open again.
2. Grant the Accessibility permission when prompted (System Settings →
   Privacy & Security → Accessibility). This lets PasteStack paste for you.

USE
• Shift+Cmd+V — open your clipboard history (card wall at bottom of screen)
• Type to search — content, text inside images (OCR), app, kind ("pdf",
  "image", "link"), or day ("yesterday", "monday")
• Arrow keys + Return to paste (Shift+Return = plain text), Esc to close
• Double-click a card to paste it; right-click for more options
• Pin favorites to Pinboards (right-click a card) — they never expire
• Menu bar icon: pause, catch-all capture, copy new screenshots to the
  clipboard, open at login, check for updates

PRIVACY
Your clipboard history stays on your Mac
(~/Library/Application Support/PasteStack). No accounts, no analytics.
The only thing PasteStack fetches from the internet is a small version file
from the GitHub repo above, to see whether an update exists. Copies from
password managers are never recorded.
